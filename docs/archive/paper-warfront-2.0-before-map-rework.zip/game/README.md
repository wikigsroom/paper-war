# 纸上兵戈：十院留名 · Godot 2.0

Godot4.7.2导入project.godot，F5运行。所有成品资产随源码提供，无需重新生成或外部建模。[制作文档](../docs/paper-warfront/README.md) · [发布包](../release/2.0.0/README.md)。

入口main.tscn；main.gd负责界面，battle_sim.gd负责60Hz模拟，map_runtime.gd负责真实图，unit_abilities.gd负责兵种/阵营能力，tactical_ai.gd负责公共规则AI，battle_view.gd负责纸偶画面，audio_controller.gd负责声音。

```powershell
godot --headless --path game --script res://tests/test_world_foundation.gd
godot --headless --path game --script res://tests/test_world_combat.gd
godot --headless --path game --script res://tests/test_campaign_play.gd -- --range 0 200
godot --path game -- --qa-world "E:/path/to/desktop-qa"
godot --path game --rendering-method gl_compatibility -- --mobile-ui --qa-world "E:/path/to/mobile-qa"
```

UI QA仅在源码项目中运行并恢复原档。已导出EXE可用`-- --demo --capture <绝对PNG路径> --quit-after-capture`进行实际画面烟测。自动结果不是人工通关证据，移动布局不是Android真机证据。

图像来源与加工在output/imagegen及tools/paper-warfront；签名私钥和网关密钥不在源包。Godot/第三方许可在licenses；字体OFL在assets/fonts。
