# 《纸上兵戈》源素材与Godot运行库

[完整制作资料](../../docs/paper-warfront/README.md) · [离线素材浏览页](gallery.html) · [素材检查报告](../../docs/paper-warfront/素材库检查报告.md)

本库保留116个基础ID、17张指定Sub2生成源板、113张加工PNG和原始声音。Godot1.0复用这些已审图像，增加53张纸偶分件、20张重新裁切的头像、三首40秒正式循环与OFL字体子集；游戏已实现三军对战、十五关和两平台导出。

[Godot运行素材浏览页](../../game/assets/runtime-gallery.html) · [运行绑定与来源](godot-integration.json) · [逐项反馈矩阵](../../docs/paper-warfront/13-运行素材与反馈矩阵.md) · [实际验收结果](../../docs/paper-warfront/15-运行验收与交付报告.md)

![运行素材造型总览](previews/godot-runtime-library.png)

![三阵营人物总览](previews/characters.png)

![法术与UI图标总览](previews/icons.png)

![建筑与场景道具总览](previews/environment.png)

![纸材、特效与背景总览](previews/materials-fx-backgrounds.png)

`library-definition.json`负责语义，`library-manifest.json`保留生成/裁切/静态审核，`runtime-manifest.json`保留源库导出映射。当前运行使用game/data/assets.json的res://路径与分件绑定。旧rig/CSS为历史提案，不能与Godot运行状态混为一谈。Windows场景验证和Android真机验证分开；APK已导出签名，尚未接入手机实测。

完整原字体与OFL在fonts/source，仅用于可复现的子集加工，不进入游戏包。源SFX44.1kHz，正式音乐22.05kHz/16bit/mono，母带与循环参数在audio/music/music-manifest.json。网关配置和Android签名私钥不在本库。
