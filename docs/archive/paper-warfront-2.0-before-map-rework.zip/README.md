# 纸上兵戈：十院留名 / Paper Warfront 2.0

Godot 4.7.2原生纸偶军团实时策略。200张机械地图、十个阵营各40作战兵、50法术、十章200关连续故事、6道附加挑战和自选地图遭遇战。

地图真实参与对战：部队走分岔与汇流路径，路标改变后续批次；矿金运输归仓、容量排队、设施施工与二维射程使经济、增援和施法时机互相牵制。4–8兵战前部署、局内科技、全套菜单/HUD、电脑对手、存档和终章已接入。

[Windows与Android下载](release/2.0.0/README.md) · [完整制作文档](docs/paper-warfront/README.md) · [地图设计与200图目录](docs/paper-warfront/world/03-200地图目录.md) · [十院故事与军库](docs/paper-warfront/world/README.md) · [完整素材/地图浏览页](assets/paper-warfront/world-v2-gallery.html) · [玩家手册](docs/paper-warfront/16-玩家手册.md) · [Godot工程](game/project.godot)。

![新Windows导出程序的分路战场](output/qa/godot/v2/export/battle.png)

自动规则、素材与原生UI检查通过，200关全局模拟正常结算，181关已取得合法自动玩家胜利。尚未完成全200关人工平衡，Android尚无真机实测。验证依据与限制见[发布报告](docs/paper-warfront/22-双平台验收与发布.md)。1.0素材/程序和地图研究保留为历史，不代表当前实现。
