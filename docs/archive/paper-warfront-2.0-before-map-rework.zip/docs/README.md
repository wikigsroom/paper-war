# 项目文档入口

- [纸上兵戈2.0制作文档](paper-warfront/README.md)：十院40兵、200地图、原生Godot系统和当前发布。
- [地图专项研究](research/swords-and-soldiers-map/README.md)：原作版本差异、关卡案例、旧1.0差距与重设计依据。
- [200图完整空间设计](paper-warfront/world/03-200地图目录.md)。
- [世界、阵营、军库与完整故事](paper-warfront/world/README.md)。
- [原作核心体验拆解](剑与勇士-HD-核心体验拆解.md)。

旧1.0共用机械地图的问题属于历史审计，新版图模块和200图已经接入当前工程。具体运行、发布与未实测项以2.0报告为准。
