# Godot架构与数据契约 · 2.0

[project.godot](../../game/project.godot)→main.tscn→main.gd。JSON定义世界、单位、科技、地图、剧情和运行资产；模拟不依赖Control、纹理、窗口或音频。

map_runtime.gd保存DAG路段、折线累积距离、节点邻接、双方路标选择、最短路、投影和edge/s/x/y锚点。battle_sim.gd处理付款、招募、研究、施工、工人任务、状态、投射物、死亡、任务与统计。unit_abilities.gd定义职责和阵营能力；tactical_ai.gd通过公共请求执行对手策略。

main.gd处理原生页面、鼠标键盘/触控、暂停、存档和指令桥接；battle_view.gd只读模拟，负责实际路网、脚点纸偶、相机、预览和反馈；map_preview.gd读取同一地图画战前简图。data_store.gd加载与校验运行绑定，纹理缓存最多140条。audio_controller.gd分发声音，audio_synth.gd提供PCM基础。

固定60Hz；真实delta积累单帧限0.15秒。request生成单侧递增序号，command校验侧别、重复序号、胜败、对象和资源后执行recruit/cancel_queue/research/build/cast/route/mine_priority。拒绝无扣费但消耗序号。队列取消同时验证索引与预期单位ID。

单位保存真实edge/s/x/y、归属、生命、冷却、状态、步态、寿命和任务标记。渲染的排次与脚线不改变战斗距离。事件带kind/time及必要的X/Y、来源、目标、单位ID、数量和半径；drain_events一次消费。近战用道路距离，远程/区域用二维欧氏距离；真实受击时再检查抗性、保护、反弹与状态。

schema2存档：unlocked(0..199)、stars、challenge_stars、loadouts、story_flags、settings和可选legacy_campaign。临时文件替换profile.json；旧十五关记录单独保存，设置/挑战保留。场景重开不保留战斗实体、队列、状态或残余FX。自动UI检查备份并恢复原档。

Windows默认Vulkan/Mobile渲染，兼容入口OpenGL；AndroidGL兼容。逻辑1600×900、横屏等比留边，移动端页数与按钮独立调整。原生APK模板导出，不使用Gradle容器或模拟器。
