# 鸢纸行会 · 40种作战单位

工人和临时召唤不计入40种。每个定义含费用、前摇、射程、移速、职责与能力；素材生产和对局验证仍在进行。

| ID | 名称 | 角色 | 金 | HP | 伤害/间隔 | 射程/速度 | 能力字段 | 职责与反制 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.yuan.vanguard | 雁羽前阵刀兵 | vanguard | 45 | 146 | 18/0.9 | 0.65/1.1 | {"faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 低费承伤；远程与控制可在其后积累。 |
| unit.yuan.archer | 雁羽折弦弓兵 | archer | 60 | 69 | 17/1.0 | 4.8/1.1 | {"reflectable": true, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 远距低费输出；需要前排，怕越线。 |
| unit.yuan.guard | 雁羽护运甲士 | guard | 70 | 223 | 14/1.1 | 0.7/0.88 | {"worker_guard_radius": 2.8, "worker_guard_reduction": 0.28, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 保护矿工运输；投入护矿会减少前线火力。 |
| unit.yuan.medic | 雁羽补页医师 | medic | 110 | 102 | 8/1.5 | 3.4/0.95 | {"heal_amount": 20, "heal_interval": 3.2, "heal_radius": 3.2, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 周期性恢复附近受伤兵；控制/爆发能突破恢复窗口。 |
| unit.yuan.javelin | 雁羽投纸矛手 | javelin | 62 | 76 | 15/1.05 | 4.2/1.05 | {"reflectable": true, "anti_fast_multiplier": 1.25, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 处理较快敌军；反弹和高甲可反制。 |
| unit.yuan.crusher | 雁羽震纸锤卫 | crusher | 96 | 217 | 33/1.75 | 0.85/0.87 | {"radius": 0.55, "stun_seconds": 0.45, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 重击打断；攻击前摇可被敌方打断。 |
| unit.yuan.artillery | 雁羽卷轴炮车 | artillery | 152 | 157 | 38/2.5 | 5.1/0.54 | {"radius": 0.6, "building_multiplier": 2.5, "reflectable": true, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 远程攻城；慢走和慢发使增援位置重要。 |
| unit.yuan.mirror | 雁羽返签卫 | mirror | 105 | 148 | 18/1.0 | 0.72/1.1 | {"reflection_cooldown": 3, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 有冷却的投射物反弹；直接法术与近战仍有效。 |
| unit.yuan.pike | 雁羽拒骑矛卫 | pike | 58 | 114 | 20/1.05 | 1.3/1.02 | {"anti_fast_multiplier": 1.55, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 克制快速冲锋；怕范围打击和长射程消耗。 |
| unit.yuan.cleaver | 雁羽裂页斧手 | cleaver | 78 | 150 | 24/1.35 | 0.8/1.02 | {"radius": 0.8, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 处理密集近战；长前摇易被控制。 |
| unit.yuan.duelist | 雁羽试刃客 | duelist | 72 | 98 | 15/0.48 | 0.7/1.23 | {"duel_multiplier": 1.22, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 单点快速交换；生命低，怕范围与远程。 |
| unit.yuan.lancer | 雁羽跃折枪兵 | lancer | 76 | 124 | 22/0.95 | 0.8/1.18 | {"leap_max_distance": 2.5, "leap_cooldown": 5, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 缩短接敌等待；不能跳到另一条路线。 |
| unit.yuan.assassin | 雁羽越阵短刃 | assassin | 106 | 96 | 30/1.15 | 0.75/1.36 | {"crossing_max_distance": 3.6, "crossing_cooldown": 6, "support_multiplier": 1.35, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 穿过局部前排威胁支援；定身阻止越线。 |
| unit.yuan.shield | 雁羽叠甲守卫 | shield | 100 | 246 | 18/1.15 | 0.75/0.82 | {"physical_damage_multiplier": 0.7, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 物理承伤；直接法术可以绕过纸甲。 |
| unit.yuan.harrier | 雁羽缚足钩兵 | harrier | 78 | 127 | 15/0.95 | 1.1/1.12 | {"on_hit_slow": 1.4, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 延缓敌方接近；远程持续输出仍能反制。 |
| unit.yuan.banner | 雁羽行军旗手 | banner | 88 | 159 | 12/1.2 | 0.7/1.0 | {"aura_speed": 0.18, "aura_radius": 3, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 改善附近部队到达相位；旗手本身输出不足。 |
| unit.yuan.drummer | 雁羽战鼓签手 | drummer | 98 | 123 | 10/1.15 | 2.1/1.0 | {"aura_damage": 0.16, "aura_radius": 3.2, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 增幅附近火力；集群站位怕范围法术。 |
| unit.yuan.engineer | 雁羽修塔匠 | engineer | 105 | 135 | 13/1.3 | 2.5/0.96 | {"repair_building": 22, "repair_interval": 3.4, "repair_radius": 3.5, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 修复近处设施；离开建筑区能力受限。 |
| unit.yuan.scribe | 雁羽禁言符师 | scribe | 122 | 88 | 13/1.4 | 4.0/1.0 | {"silence_seconds": 1.6, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 暂时禁止敌人自动特殊能力；普通攻击不受影响。 |
| unit.yuan.poisoner | 雁羽腐墨针手 | poisoner | 62 | 76 | 9/1.2 | 4.0/1.1 | {"poison_damage_per_second": 4, "reflectable": true, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 持续伤害；清除后排或免伤可阻止累积。 |
| unit.yuan.burner | 雁羽焚边签兵 | burner | 106 | 86 | 16/1.4 | 3.8/0.99 | {"burn_damage_per_second": 6, "radius": 0.4, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 范围灼烧；低生命与较长周期限制持续火力。 |
| unit.yuan.sniper | 雁羽望页弩手 | sniper | 136 | 75 | 46/2.2 | 6.2/0.89 | {"support_priority": true, "reflectable": true, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 优先攻击支援；慢射击给救援法术留下窗口。 |
| unit.yuan.repeater | 雁羽连签火手 | repeater | 104 | 96 | 11/1.75 | 4.2/1.04 | {"burst_count": 3, "reflectable": true, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 多次投射；单发反弹会打断火力收益。 |
| unit.yuan.siege | 雁羽撞印车 | siege | 164 | 318 | 40/2.0 | 1.1/0.58 | {"building_multiplier": 3.0, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 高建筑伤害；面对军团时效率低。 |
| unit.yuan.mortar | 雁羽抛墨臼 | mortar | 175 | 118 | 43/3.1 | 6.0/0.58 | {"radius": 1.2, "reflectable": false, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 远距范围弹；长前摇和低耐久可被突袭。 |
| unit.yuan.chain | 雁羽连墨术士 | chain | 146 | 90 | 22/1.9 | 4.5/0.93 | {"chain_targets": 3, "chain_radius": 2.2, "reflectable": false, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 弹跳处理集群；分开站位降低价值。 |
| unit.yuan.executioner | 雁羽断页刑兵 | executioner | 118 | 162 | 31/1.25 | 0.85/1.04 | {"execute_threshold": 0.35, "execute_multiplier": 1.7, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 收割低血单位；满血前排可以拖住。 |
| unit.yuan.leech | 雁羽夺血纸客 | leech | 120 | 133 | 23/1.1 | 0.75/1.14 | {"lifesteal": 0.28, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 近战吸血续航；控制和集中火力压过恢复。 |
| unit.yuan.raider | 雁羽截金游兵 | raider | 84 | 109 | 17/0.8 | 0.7/1.3 | {"worker_multiplier": 2.4, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 快速截工；正面耐久不足。 |
| unit.yuan.demolisher | 雁羽拆灯斧匠 | demolisher | 128 | 200 | 25/1.4 | 0.9/0.97 | {"building_multiplier": 2.8, "construction_multiplier": 1.5, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 抢拆设施尤其施工目标；怕远程与迟到。 |
| unit.yuan.summoner | 雁羽唤卫符使 | summoner | 172 | 102 | 10/1.55 | 3.5/0.92 | {"auto_guardian_seconds": 12, "ability_interval": 7, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 周期召临时护卫；有限所有权与寿命避免无限成军。 |
| unit.yuan.necromancer | 雁羽拾页祭司 | necromancer | 158 | 89 | 7/1.4 | 3.8/0.95 | {"corpse_summon": true, "corpse_range": 3.6, "summon_interval": 3, "max_owned_thralls": 4, "faction_trait": "junction_haste", "summons": "unit.mo.thrall", "junction_haste_seconds": 3.5} | 消费附近纸标复兵；纸标不足或被争夺时无效。 |
| unit.yuan.illusionist | 雁羽复影校书 | illusionist | 162 | 104 | 13/1.5 | 3.7/0.98 | {"auto_clone_seconds": 8, "ability_interval": 9, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 复制附近普通兵；有限寿命，禁复制链与巨人。 |
| unit.yuan.saboteur | 雁羽熄台潜客 | saboteur | 130 | 116 | 19/1.15 | 0.8/1.25 | {"disable_facility_seconds": 3, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 短时熄灭设施能力；无法永久免费拆塔。 |
| unit.yuan.warden | 雁羽钉页卫 | warden | 103 | 182 | 17/1.3 | 1.1/0.94 | {"root_seconds": 1.1, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 命中定身，敌人仍可攻击；长射程可反制。 |
| unit.yuan.berserker | 雁羽破缄狂兵 | berserker | 125 | 198 | 27/1.15 | 0.8/1.07 | {"enrage_threshold": 0.35, "enrage_multiplier": 1.7, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 低血爆发；控制后清除而非慢慢消耗。 |
| unit.yuan.colossus | 雁羽厚页巨像 | colossus | 270 | 592 | 67/2.9 | 1.35/0.54 | {"radius": 1.2, "giant": true, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 耐久范围重击；昂贵慢走，前摇可打断。 |
| unit.yuan.caravan | 雁羽护矿执旗 | caravan | 115 | 157 | 14/1.05 | 2.8/1.07 | {"delivery_aura": 2, "aura_radius": 3.2, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 提高附近工人的每趟实际交付；依赖同路护运。 |
| unit.yuan.oracle | 雁羽观墨师 | oracle | 146 | 95 | 20/1.7 | 4.8/0.94 | {"kill_mana": 5, "magic_damage": true, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 魔法输出与合法击杀回法；怕突袭，召唤不能刷回法。 |
| unit.yuan.phoenix | 雁羽燃尽重卫 | phoenix | 165 | 237 | 28/1.7 | 0.9/0.85 | {"death_burst_damage": 45, "death_burst_radius": 1.7, "faction_trait": "junction_haste", "junction_haste_seconds": 3.5} | 死亡时局部爆发；不能伤到远处和另一条分离路线。 |
