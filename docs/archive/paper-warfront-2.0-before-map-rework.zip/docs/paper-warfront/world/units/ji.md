# 纸械工坊 · 40种作战单位

工人和临时召唤不计入40种。每个定义含费用、前摇、射程、移速、职责与能力；素材生产和对局验证仍在进行。

| ID | 名称 | 角色 | 金 | HP | 伤害/间隔 | 射程/速度 | 能力字段 | 职责与反制 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.ji.vanguard | 铜折前阵刀兵 | vanguard | 45 | 160 | 18/0.9 | 0.65/1.023 | {"faction_trait": "workshop", "workshop_bonus": 0.22} | 低费承伤；远程与控制可在其后积累。 |
| unit.ji.archer | 铜折折弦弓兵 | archer | 60 | 76 | 17/1.0 | 4.8/1.023 | {"reflectable": true, "faction_trait": "workshop", "workshop_bonus": 0.22} | 远距低费输出；需要前排，怕越线。 |
| unit.ji.guard | 铜折护运甲士 | guard | 70 | 245 | 14/1.1 | 0.7/0.818 | {"worker_guard_radius": 2.8, "worker_guard_reduction": 0.28, "faction_trait": "workshop", "workshop_bonus": 0.22} | 保护矿工运输；投入护矿会减少前线火力。 |
| unit.ji.medic | 铜折补页医师 | medic | 110 | 112 | 8/1.5 | 3.4/0.883 | {"heal_amount": 20, "heal_interval": 3.2, "heal_radius": 3.2, "faction_trait": "workshop", "workshop_bonus": 0.22} | 周期性恢复附近受伤兵；控制/爆发能突破恢复窗口。 |
| unit.ji.javelin | 铜折投纸矛手 | javelin | 62 | 83 | 15/1.05 | 4.2/0.977 | {"reflectable": true, "anti_fast_multiplier": 1.25, "faction_trait": "workshop", "workshop_bonus": 0.22} | 处理较快敌军；反弹和高甲可反制。 |
| unit.ji.crusher | 铜折震纸锤卫 | crusher | 96 | 238 | 33/1.75 | 0.85/0.809 | {"radius": 0.55, "stun_seconds": 0.45, "faction_trait": "workshop", "workshop_bonus": 0.22} | 重击打断；攻击前摇可被敌方打断。 |
| unit.ji.artillery | 铜折卷轴炮车 | artillery | 152 | 172 | 38/2.5 | 5.1/0.502 | {"radius": 0.6, "building_multiplier": 2.5, "reflectable": true, "faction_trait": "workshop", "workshop_bonus": 0.22} | 远程攻城；慢走和慢发使增援位置重要。 |
| unit.ji.mirror | 铜折返签卫 | mirror | 105 | 163 | 18/1.0 | 0.72/1.023 | {"reflection_cooldown": 3, "faction_trait": "workshop", "workshop_bonus": 0.22} | 有冷却的投射物反弹；直接法术与近战仍有效。 |
| unit.ji.pike | 铜折拒骑矛卫 | pike | 58 | 125 | 20/1.05 | 1.3/0.949 | {"anti_fast_multiplier": 1.55, "faction_trait": "workshop", "workshop_bonus": 0.22} | 克制快速冲锋；怕范围打击和长射程消耗。 |
| unit.ji.cleaver | 铜折裂页斧手 | cleaver | 78 | 165 | 24/1.35 | 0.8/0.949 | {"radius": 0.8, "faction_trait": "workshop", "workshop_bonus": 0.22} | 处理密集近战；长前摇易被控制。 |
| unit.ji.duelist | 铜折试刃客 | duelist | 72 | 108 | 15/0.48 | 0.7/1.144 | {"duel_multiplier": 1.22, "faction_trait": "workshop", "workshop_bonus": 0.22} | 单点快速交换；生命低，怕范围与远程。 |
| unit.ji.lancer | 铜折跃折枪兵 | lancer | 76 | 136 | 22/0.95 | 0.8/1.097 | {"leap_max_distance": 2.5, "leap_cooldown": 5, "faction_trait": "workshop", "workshop_bonus": 0.22} | 缩短接敌等待；不能跳到另一条路线。 |
| unit.ji.assassin | 铜折越阵短刃 | assassin | 106 | 105 | 30/1.15 | 0.75/1.265 | {"crossing_max_distance": 3.6, "crossing_cooldown": 6, "support_multiplier": 1.35, "faction_trait": "workshop", "workshop_bonus": 0.22} | 穿过局部前排威胁支援；定身阻止越线。 |
| unit.ji.shield | 铜折叠甲守卫 | shield | 100 | 270 | 18/1.15 | 0.75/0.763 | {"physical_damage_multiplier": 0.7, "faction_trait": "workshop", "workshop_bonus": 0.22} | 物理承伤；直接法术可以绕过纸甲。 |
| unit.ji.harrier | 铜折缚足钩兵 | harrier | 78 | 140 | 15/0.95 | 1.1/1.042 | {"on_hit_slow": 1.4, "faction_trait": "workshop", "workshop_bonus": 0.22} | 延缓敌方接近；远程持续输出仍能反制。 |
| unit.ji.banner | 铜折行军旗手 | banner | 88 | 175 | 12/1.2 | 0.7/0.93 | {"aura_speed": 0.18, "aura_radius": 3, "faction_trait": "workshop", "workshop_bonus": 0.22} | 改善附近部队到达相位；旗手本身输出不足。 |
| unit.ji.drummer | 铜折战鼓签手 | drummer | 98 | 135 | 10/1.15 | 2.1/0.93 | {"aura_damage": 0.16, "aura_radius": 3.2, "faction_trait": "workshop", "workshop_bonus": 0.22} | 增幅附近火力；集群站位怕范围法术。 |
| unit.ji.engineer | 铜折修塔匠 | engineer | 105 | 148 | 13/1.3 | 2.5/0.893 | {"repair_building": 22, "repair_interval": 3.4, "repair_radius": 3.5, "faction_trait": "workshop", "workshop_bonus": 0.22} | 修复近处设施；离开建筑区能力受限。 |
| unit.ji.scribe | 铜折禁言符师 | scribe | 122 | 97 | 13/1.4 | 4.0/0.93 | {"silence_seconds": 1.6, "faction_trait": "workshop", "workshop_bonus": 0.22} | 暂时禁止敌人自动特殊能力；普通攻击不受影响。 |
| unit.ji.poisoner | 铜折腐墨针手 | poisoner | 62 | 84 | 9/1.2 | 4.0/1.023 | {"poison_damage_per_second": 4, "reflectable": true, "faction_trait": "workshop", "workshop_bonus": 0.22} | 持续伤害；清除后排或免伤可阻止累积。 |
| unit.ji.burner | 铜折焚边签兵 | burner | 106 | 94 | 16/1.4 | 3.8/0.921 | {"burn_damage_per_second": 6, "radius": 0.4, "faction_trait": "workshop", "workshop_bonus": 0.22} | 范围灼烧；低生命与较长周期限制持续火力。 |
| unit.ji.sniper | 铜折望页弩手 | sniper | 136 | 82 | 46/2.2 | 6.2/0.828 | {"support_priority": true, "reflectable": true, "faction_trait": "workshop", "workshop_bonus": 0.22} | 优先攻击支援；慢射击给救援法术留下窗口。 |
| unit.ji.repeater | 铜折连签火手 | repeater | 104 | 105 | 11/1.75 | 4.2/0.967 | {"burst_count": 3, "reflectable": true, "faction_trait": "workshop", "workshop_bonus": 0.22} | 多次投射；单发反弹会打断火力收益。 |
| unit.ji.siege | 铜折撞印车 | siege | 164 | 350 | 40/2.0 | 1.1/0.539 | {"building_multiplier": 3.0, "faction_trait": "workshop", "workshop_bonus": 0.22} | 高建筑伤害；面对军团时效率低。 |
| unit.ji.mortar | 铜折抛墨臼 | mortar | 175 | 130 | 43/3.1 | 6.0/0.539 | {"radius": 1.2, "reflectable": false, "faction_trait": "workshop", "workshop_bonus": 0.22} | 远距范围弹；长前摇和低耐久可被突袭。 |
| unit.ji.chain | 铜折连墨术士 | chain | 146 | 99 | 22/1.9 | 4.5/0.865 | {"chain_targets": 3, "chain_radius": 2.2, "reflectable": false, "faction_trait": "workshop", "workshop_bonus": 0.22} | 弹跳处理集群；分开站位降低价值。 |
| unit.ji.executioner | 铜折断页刑兵 | executioner | 118 | 178 | 31/1.25 | 0.85/0.967 | {"execute_threshold": 0.35, "execute_multiplier": 1.7, "faction_trait": "workshop", "workshop_bonus": 0.22} | 收割低血单位；满血前排可以拖住。 |
| unit.ji.leech | 铜折夺血纸客 | leech | 120 | 146 | 23/1.1 | 0.75/1.06 | {"lifesteal": 0.28, "faction_trait": "workshop", "workshop_bonus": 0.22} | 近战吸血续航；控制和集中火力压过恢复。 |
| unit.ji.raider | 铜折截金游兵 | raider | 84 | 120 | 17/0.8 | 0.7/1.209 | {"worker_multiplier": 2.4, "faction_trait": "workshop", "workshop_bonus": 0.22} | 快速截工；正面耐久不足。 |
| unit.ji.demolisher | 铜折拆灯斧匠 | demolisher | 128 | 220 | 25/1.4 | 0.9/0.902 | {"building_multiplier": 2.8, "construction_multiplier": 1.5, "faction_trait": "workshop", "workshop_bonus": 0.22} | 抢拆设施尤其施工目标；怕远程与迟到。 |
| unit.ji.summoner | 铜折唤卫符使 | summoner | 172 | 112 | 10/1.55 | 3.5/0.856 | {"auto_guardian_seconds": 12, "ability_interval": 7, "faction_trait": "workshop", "workshop_bonus": 0.22} | 周期召临时护卫；有限所有权与寿命避免无限成军。 |
| unit.ji.necromancer | 铜折拾页祭司 | necromancer | 158 | 98 | 7/1.4 | 3.8/0.883 | {"corpse_summon": true, "corpse_range": 3.6, "summon_interval": 3, "max_owned_thralls": 4, "faction_trait": "workshop", "summons": "unit.mo.thrall", "workshop_bonus": 0.22} | 消费附近纸标复兵；纸标不足或被争夺时无效。 |
| unit.ji.illusionist | 铜折复影校书 | illusionist | 162 | 114 | 13/1.5 | 3.7/0.911 | {"auto_clone_seconds": 8, "ability_interval": 9, "faction_trait": "workshop", "workshop_bonus": 0.22} | 复制附近普通兵；有限寿命，禁复制链与巨人。 |
| unit.ji.saboteur | 铜折熄台潜客 | saboteur | 130 | 127 | 19/1.15 | 0.8/1.163 | {"disable_facility_seconds": 3, "faction_trait": "workshop", "workshop_bonus": 0.22} | 短时熄灭设施能力；无法永久免费拆塔。 |
| unit.ji.warden | 铜折钉页卫 | warden | 103 | 200 | 17/1.3 | 1.1/0.874 | {"root_seconds": 1.1, "faction_trait": "workshop", "workshop_bonus": 0.22} | 命中定身，敌人仍可攻击；长射程可反制。 |
| unit.ji.berserker | 铜折破缄狂兵 | berserker | 125 | 218 | 27/1.15 | 0.8/0.995 | {"enrage_threshold": 0.35, "enrage_multiplier": 1.7, "faction_trait": "workshop", "workshop_bonus": 0.22} | 低血爆发；控制后清除而非慢慢消耗。 |
| unit.ji.colossus | 铜折厚页巨像 | colossus | 270 | 650 | 67/2.9 | 1.35/0.502 | {"radius": 1.2, "giant": true, "faction_trait": "workshop", "workshop_bonus": 0.22} | 耐久范围重击；昂贵慢走，前摇可打断。 |
| unit.ji.caravan | 铜折护矿执旗 | caravan | 115 | 172 | 14/1.05 | 2.8/0.995 | {"delivery_aura": 2, "aura_radius": 3.2, "faction_trait": "workshop", "workshop_bonus": 0.22} | 提高附近工人的每趟实际交付；依赖同路护运。 |
| unit.ji.oracle | 铜折观墨师 | oracle | 146 | 104 | 20/1.7 | 4.8/0.874 | {"kill_mana": 5, "magic_damage": true, "faction_trait": "workshop", "workshop_bonus": 0.22} | 魔法输出与合法击杀回法；怕突袭，召唤不能刷回法。 |
| unit.ji.phoenix | 铜折燃尽重卫 | phoenix | 165 | 260 | 28/1.7 | 0.9/0.79 | {"death_burst_damage": 45, "death_burst_radius": 1.7, "faction_trait": "workshop", "workshop_bonus": 0.22} | 死亡时局部爆发；不能伤到远处和另一条分离路线。 |
