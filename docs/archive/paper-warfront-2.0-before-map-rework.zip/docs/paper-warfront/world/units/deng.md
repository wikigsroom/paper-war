# 灯符朝 · 40种作战单位

工人和临时召唤不计入40种。每个定义含费用、前摇、射程、移速、职责与能力；素材生产和对局验证仍在进行。

| ID | 名称 | 角色 | 金 | HP | 伤害/间隔 | 射程/速度 | 能力字段 | 职责与反制 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.deng.mirror | 青符返签卫 | mirror | 50 | 140 | 17/0.92 | 0.65/1.12 | {"reflection_cooldown": 3, "faction_trait": "ward"} | 有冷却的投射物反弹；直接法术与近战仍有效。 |
| unit.deng.fire | 青符连签火手 | repeater | 65 | 70 | 14/2.4 | 4.4/1.05 | {"burst_count": 2, "reflectable": true, "faction_trait": "ward"} | 多次投射；单发反弹会打断火力收益。 |
| unit.deng.shadow | 青符越阵短刃 | assassin | 90 | 105 | 21/0.8 | 0.6/1.35 | {"crossing_max_distance": 3.6, "crossing_cooldown": 6, "support_multiplier": 1.35, "faction_trait": "ward"} | 穿过局部前排威胁支援；定身阻止越线。 |
| unit.deng.effigy | 青符叠甲守卫 | shield | 110 | 280 | 24/1.3 | 0.95/0.72 | {"physical_damage_multiplier": 0.75, "faction_trait": "ward"} | 物理承伤；直接法术可以绕过纸甲。 |
| unit.deng.vanguard | 青符前阵刀兵 | vanguard | 45 | 160 | 18/0.9 | 0.65/1.1 | {"faction_trait": "ward"} | 低费承伤；远程与控制可在其后积累。 |
| unit.deng.archer | 青符折弦弓兵 | archer | 60 | 76 | 17/1.0 | 4.8/1.1 | {"reflectable": true, "faction_trait": "ward"} | 远距低费输出；需要前排，怕越线。 |
| unit.deng.guard | 青符护运甲士 | guard | 70 | 245 | 14/1.1 | 0.7/0.88 | {"worker_guard_radius": 2.8, "worker_guard_reduction": 0.28, "faction_trait": "ward"} | 保护矿工运输；投入护矿会减少前线火力。 |
| unit.deng.medic | 青符补页医师 | medic | 110 | 112 | 8/1.5 | 3.4/0.95 | {"heal_amount": 20, "heal_interval": 3.2, "heal_radius": 3.2, "faction_trait": "ward"} | 周期性恢复附近受伤兵；控制/爆发能突破恢复窗口。 |
| unit.deng.pike | 青符拒骑矛卫 | pike | 58 | 125 | 20/1.05 | 1.3/1.02 | {"anti_fast_multiplier": 1.55, "faction_trait": "ward"} | 克制快速冲锋；怕范围打击和长射程消耗。 |
| unit.deng.cleaver | 青符裂页斧手 | cleaver | 78 | 165 | 24/1.35 | 0.8/1.02 | {"radius": 0.8, "faction_trait": "ward"} | 处理密集近战；长前摇易被控制。 |
| unit.deng.duelist | 青符试刃客 | duelist | 72 | 108 | 15/0.48 | 0.7/1.23 | {"duel_multiplier": 1.22, "faction_trait": "ward"} | 单点快速交换；生命低，怕范围与远程。 |
| unit.deng.lancer | 青符跃折枪兵 | lancer | 76 | 136 | 22/0.95 | 0.8/1.18 | {"leap_max_distance": 2.5, "leap_cooldown": 5, "faction_trait": "ward"} | 缩短接敌等待；不能跳到另一条路线。 |
| unit.deng.crusher | 青符震纸锤卫 | crusher | 96 | 238 | 33/1.75 | 0.85/0.87 | {"radius": 0.55, "stun_seconds": 0.45, "faction_trait": "ward"} | 重击打断；攻击前摇可被敌方打断。 |
| unit.deng.harrier | 青符缚足钩兵 | harrier | 78 | 140 | 15/0.95 | 1.1/1.12 | {"on_hit_slow": 1.4, "faction_trait": "ward"} | 延缓敌方接近；远程持续输出仍能反制。 |
| unit.deng.banner | 青符行军旗手 | banner | 88 | 175 | 12/1.2 | 0.7/1.0 | {"aura_speed": 0.18, "aura_radius": 3, "faction_trait": "ward"} | 改善附近部队到达相位；旗手本身输出不足。 |
| unit.deng.drummer | 青符战鼓签手 | drummer | 98 | 135 | 10/1.15 | 2.1/1.0 | {"aura_damage": 0.16, "aura_radius": 3.2, "faction_trait": "ward"} | 增幅附近火力；集群站位怕范围法术。 |
| unit.deng.engineer | 青符修塔匠 | engineer | 105 | 148 | 13/1.3 | 2.5/0.96 | {"repair_building": 22, "repair_interval": 3.4, "repair_radius": 3.5, "faction_trait": "ward"} | 修复近处设施；离开建筑区能力受限。 |
| unit.deng.scribe | 青符禁言符师 | scribe | 122 | 97 | 13/1.4 | 4.0/1.0 | {"silence_seconds": 1.6, "faction_trait": "ward"} | 暂时禁止敌人自动特殊能力；普通攻击不受影响。 |
| unit.deng.poisoner | 青符腐墨针手 | poisoner | 62 | 84 | 9/1.2 | 4.0/1.1 | {"poison_damage_per_second": 4, "reflectable": true, "faction_trait": "ward"} | 持续伤害；清除后排或免伤可阻止累积。 |
| unit.deng.burner | 青符焚边签兵 | burner | 106 | 94 | 16/1.4 | 3.8/0.99 | {"burn_damage_per_second": 6, "radius": 0.4, "faction_trait": "ward"} | 范围灼烧；低生命与较长周期限制持续火力。 |
| unit.deng.javelin | 青符投纸矛手 | javelin | 62 | 83 | 15/1.05 | 4.2/1.05 | {"reflectable": true, "anti_fast_multiplier": 1.25, "faction_trait": "ward"} | 处理较快敌军；反弹和高甲可反制。 |
| unit.deng.sniper | 青符望页弩手 | sniper | 136 | 82 | 46/2.2 | 6.2/0.89 | {"support_priority": true, "reflectable": true, "faction_trait": "ward"} | 优先攻击支援；慢射击给救援法术留下窗口。 |
| unit.deng.artillery | 青符卷轴炮车 | artillery | 152 | 172 | 38/2.5 | 5.1/0.54 | {"radius": 0.6, "building_multiplier": 2.5, "reflectable": true, "faction_trait": "ward"} | 远程攻城；慢走和慢发使增援位置重要。 |
| unit.deng.siege | 青符撞印车 | siege | 164 | 350 | 40/2.0 | 1.1/0.58 | {"building_multiplier": 3.0, "faction_trait": "ward"} | 高建筑伤害；面对军团时效率低。 |
| unit.deng.mortar | 青符抛墨臼 | mortar | 175 | 130 | 43/3.1 | 6.0/0.58 | {"radius": 1.2, "reflectable": false, "faction_trait": "ward"} | 远距范围弹；长前摇和低耐久可被突袭。 |
| unit.deng.chain | 青符连墨术士 | chain | 146 | 99 | 22/1.9 | 4.5/0.93 | {"chain_targets": 3, "chain_radius": 2.2, "reflectable": false, "faction_trait": "ward"} | 弹跳处理集群；分开站位降低价值。 |
| unit.deng.executioner | 青符断页刑兵 | executioner | 118 | 178 | 31/1.25 | 0.85/1.04 | {"execute_threshold": 0.35, "execute_multiplier": 1.7, "faction_trait": "ward"} | 收割低血单位；满血前排可以拖住。 |
| unit.deng.leech | 青符夺血纸客 | leech | 120 | 146 | 23/1.1 | 0.75/1.14 | {"lifesteal": 0.28, "faction_trait": "ward"} | 近战吸血续航；控制和集中火力压过恢复。 |
| unit.deng.raider | 青符截金游兵 | raider | 84 | 120 | 17/0.8 | 0.7/1.3 | {"worker_multiplier": 2.4, "faction_trait": "ward"} | 快速截工；正面耐久不足。 |
| unit.deng.demolisher | 青符拆灯斧匠 | demolisher | 128 | 220 | 25/1.4 | 0.9/0.97 | {"building_multiplier": 2.8, "construction_multiplier": 1.5, "faction_trait": "ward"} | 抢拆设施尤其施工目标；怕远程与迟到。 |
| unit.deng.summoner | 青符唤卫符使 | summoner | 172 | 112 | 10/1.55 | 3.5/0.92 | {"auto_guardian_seconds": 12, "ability_interval": 7, "faction_trait": "ward"} | 周期召临时护卫；有限所有权与寿命避免无限成军。 |
| unit.deng.necromancer | 青符拾页祭司 | necromancer | 158 | 98 | 7/1.4 | 3.8/0.95 | {"corpse_summon": true, "corpse_range": 3.6, "summon_interval": 3, "max_owned_thralls": 4, "faction_trait": "ward", "summons": "unit.mo.thrall"} | 消费附近纸标复兵；纸标不足或被争夺时无效。 |
| unit.deng.illusionist | 青符复影校书 | illusionist | 162 | 114 | 13/1.5 | 3.7/0.98 | {"auto_clone_seconds": 8, "ability_interval": 9, "faction_trait": "ward"} | 复制附近普通兵；有限寿命，禁复制链与巨人。 |
| unit.deng.saboteur | 青符熄台潜客 | saboteur | 130 | 127 | 19/1.15 | 0.8/1.25 | {"disable_facility_seconds": 3, "faction_trait": "ward"} | 短时熄灭设施能力；无法永久免费拆塔。 |
| unit.deng.warden | 青符钉页卫 | warden | 103 | 200 | 17/1.3 | 1.1/0.94 | {"root_seconds": 1.1, "faction_trait": "ward"} | 命中定身，敌人仍可攻击；长射程可反制。 |
| unit.deng.berserker | 青符破缄狂兵 | berserker | 125 | 218 | 27/1.15 | 0.8/1.07 | {"enrage_threshold": 0.35, "enrage_multiplier": 1.7, "faction_trait": "ward"} | 低血爆发；控制后清除而非慢慢消耗。 |
| unit.deng.colossus | 青符厚页巨像 | colossus | 270 | 650 | 67/2.9 | 1.35/0.54 | {"radius": 1.2, "giant": true, "faction_trait": "ward"} | 耐久范围重击；昂贵慢走，前摇可打断。 |
| unit.deng.caravan | 青符护矿执旗 | caravan | 115 | 172 | 14/1.05 | 2.8/1.07 | {"delivery_aura": 2, "aura_radius": 3.2, "faction_trait": "ward"} | 提高附近工人的每趟实际交付；依赖同路护运。 |
| unit.deng.oracle | 青符观墨师 | oracle | 146 | 104 | 20/1.7 | 4.8/0.94 | {"kill_mana": 5, "magic_damage": true, "faction_trait": "ward"} | 魔法输出与合法击杀回法；怕突袭，召唤不能刷回法。 |
| unit.deng.phoenix | 青符燃尽重卫 | phoenix | 165 | 260 | 28/1.7 | 0.9/0.85 | {"death_burst_damage": 45, "death_burst_radius": 1.7, "faction_trait": "ward"} | 死亡时局部爆发；不能伤到远处和另一条分离路线。 |
