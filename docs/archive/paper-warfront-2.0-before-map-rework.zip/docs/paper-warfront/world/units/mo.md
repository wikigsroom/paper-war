# 墨骸社 · 40种作战单位

工人和临时召唤不计入40种。每个定义含费用、前摇、射程、移速、职责与能力；素材生产和对局验证仍在进行。

| ID | 名称 | 角色 | 金 | HP | 伤害/间隔 | 射程/速度 | 能力字段 | 职责与反制 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.mo.blade | 旧墨跃折枪兵 | lancer | 40 | 113 | 20/0.72 | 0.65/1.24 | {"leap_max_distance": 2.6, "leap_cooldown": 5, "faction_trait": "lifesteal", "lifesteal": 0.1} | 缩短接敌等待；不能跳到另一条路线。 |
| unit.mo.needle | 旧墨腐墨针手 | poisoner | 55 | 61 | 9/1.25 | 4.1/1.08 | {"poison_damage_per_second": 4, "reflectable": true, "poison_seconds": 3, "faction_trait": "lifesteal", "lifesteal": 0.1} | 持续伤害；清除后排或免伤可阻止累积。 |
| unit.mo.priest | 旧墨拾页祭司 | necromancer | 95 | 85 | 6/1.6 | 3.4/0.95 | {"corpse_summon": true, "corpse_range": 3.6, "summon_interval": 3, "max_owned_thralls": 4, "reflectable": true, "summons": "unit.mo.thrall", "faction_trait": "lifesteal", "lifesteal": 0.1} | 消费附近纸标复兵；纸标不足或被争夺时无效。 |
| unit.mo.giant | 旧墨厚页巨像 | colossus | 190 | 611 | 62/2.2 | 1.0/0.54 | {"radius": 1.1, "giant": true, "faction_trait": "lifesteal", "lifesteal": 0.1} | 耐久范围重击；昂贵慢走，前摇可打断。 |
| unit.mo.vanguard | 旧墨前阵刀兵 | vanguard | 45 | 150 | 18/0.9 | 0.65/1.1 | {"faction_trait": "lifesteal", "lifesteal": 0.1} | 低费承伤；远程与控制可在其后积累。 |
| unit.mo.archer | 旧墨折弦弓兵 | archer | 60 | 71 | 17/1.0 | 4.8/1.1 | {"reflectable": true, "faction_trait": "lifesteal", "lifesteal": 0.1} | 远距低费输出；需要前排，怕越线。 |
| unit.mo.guard | 旧墨护运甲士 | guard | 70 | 230 | 14/1.1 | 0.7/0.88 | {"worker_guard_radius": 2.8, "worker_guard_reduction": 0.28, "faction_trait": "lifesteal", "lifesteal": 0.1} | 保护矿工运输；投入护矿会减少前线火力。 |
| unit.mo.medic | 旧墨补页医师 | medic | 110 | 105 | 8/1.5 | 3.4/0.95 | {"heal_amount": 20, "heal_interval": 3.2, "heal_radius": 3.2, "faction_trait": "lifesteal", "lifesteal": 0.1} | 周期性恢复附近受伤兵；控制/爆发能突破恢复窗口。 |
| unit.mo.pike | 旧墨拒骑矛卫 | pike | 58 | 118 | 20/1.05 | 1.3/1.02 | {"anti_fast_multiplier": 1.55, "faction_trait": "lifesteal", "lifesteal": 0.1} | 克制快速冲锋；怕范围打击和长射程消耗。 |
| unit.mo.cleaver | 旧墨裂页斧手 | cleaver | 78 | 155 | 24/1.35 | 0.8/1.02 | {"radius": 0.8, "faction_trait": "lifesteal", "lifesteal": 0.1} | 处理密集近战；长前摇易被控制。 |
| unit.mo.duelist | 旧墨试刃客 | duelist | 72 | 102 | 15/0.48 | 0.7/1.23 | {"duel_multiplier": 1.22, "faction_trait": "lifesteal", "lifesteal": 0.1} | 单点快速交换；生命低，怕范围与远程。 |
| unit.mo.assassin | 旧墨越阵短刃 | assassin | 106 | 99 | 30/1.15 | 0.75/1.36 | {"crossing_max_distance": 3.6, "crossing_cooldown": 6, "support_multiplier": 1.35, "faction_trait": "lifesteal", "lifesteal": 0.1} | 穿过局部前排威胁支援；定身阻止越线。 |
| unit.mo.shield | 旧墨叠甲守卫 | shield | 100 | 254 | 18/1.15 | 0.75/0.82 | {"physical_damage_multiplier": 0.7, "faction_trait": "lifesteal", "lifesteal": 0.1} | 物理承伤；直接法术可以绕过纸甲。 |
| unit.mo.crusher | 旧墨震纸锤卫 | crusher | 96 | 224 | 33/1.75 | 0.85/0.87 | {"radius": 0.55, "stun_seconds": 0.45, "faction_trait": "lifesteal", "lifesteal": 0.1} | 重击打断；攻击前摇可被敌方打断。 |
| unit.mo.harrier | 旧墨缚足钩兵 | harrier | 78 | 132 | 15/0.95 | 1.1/1.12 | {"on_hit_slow": 1.4, "faction_trait": "lifesteal", "lifesteal": 0.1} | 延缓敌方接近；远程持续输出仍能反制。 |
| unit.mo.banner | 旧墨行军旗手 | banner | 88 | 164 | 12/1.2 | 0.7/1.0 | {"aura_speed": 0.18, "aura_radius": 3, "faction_trait": "lifesteal", "lifesteal": 0.1} | 改善附近部队到达相位；旗手本身输出不足。 |
| unit.mo.drummer | 旧墨战鼓签手 | drummer | 98 | 127 | 10/1.15 | 2.1/1.0 | {"aura_damage": 0.16, "aura_radius": 3.2, "faction_trait": "lifesteal", "lifesteal": 0.1} | 增幅附近火力；集群站位怕范围法术。 |
| unit.mo.engineer | 旧墨修塔匠 | engineer | 105 | 139 | 13/1.3 | 2.5/0.96 | {"repair_building": 22, "repair_interval": 3.4, "repair_radius": 3.5, "faction_trait": "lifesteal", "lifesteal": 0.1} | 修复近处设施；离开建筑区能力受限。 |
| unit.mo.mirror | 旧墨返签卫 | mirror | 105 | 153 | 18/1.0 | 0.72/1.1 | {"reflection_cooldown": 3, "faction_trait": "lifesteal", "lifesteal": 0.1} | 有冷却的投射物反弹；直接法术与近战仍有效。 |
| unit.mo.scribe | 旧墨禁言符师 | scribe | 122 | 91 | 13/1.4 | 4.0/1.0 | {"silence_seconds": 1.6, "faction_trait": "lifesteal", "lifesteal": 0.1} | 暂时禁止敌人自动特殊能力；普通攻击不受影响。 |
| unit.mo.burner | 旧墨焚边签兵 | burner | 106 | 88 | 16/1.4 | 3.8/0.99 | {"burn_damage_per_second": 6, "radius": 0.4, "faction_trait": "lifesteal", "lifesteal": 0.1} | 范围灼烧；低生命与较长周期限制持续火力。 |
| unit.mo.javelin | 旧墨投纸矛手 | javelin | 62 | 78 | 15/1.05 | 4.2/1.05 | {"reflectable": true, "anti_fast_multiplier": 1.25, "faction_trait": "lifesteal", "lifesteal": 0.1} | 处理较快敌军；反弹和高甲可反制。 |
| unit.mo.sniper | 旧墨望页弩手 | sniper | 136 | 77 | 46/2.2 | 6.2/0.89 | {"support_priority": true, "reflectable": true, "faction_trait": "lifesteal", "lifesteal": 0.1} | 优先攻击支援；慢射击给救援法术留下窗口。 |
| unit.mo.repeater | 旧墨连签火手 | repeater | 104 | 99 | 11/1.75 | 4.2/1.04 | {"burst_count": 3, "reflectable": true, "faction_trait": "lifesteal", "lifesteal": 0.1} | 多次投射；单发反弹会打断火力收益。 |
| unit.mo.artillery | 旧墨卷轴炮车 | artillery | 152 | 162 | 38/2.5 | 5.1/0.54 | {"radius": 0.6, "building_multiplier": 2.5, "reflectable": true, "faction_trait": "lifesteal", "lifesteal": 0.1} | 远程攻城；慢走和慢发使增援位置重要。 |
| unit.mo.siege | 旧墨撞印车 | siege | 164 | 329 | 40/2.0 | 1.1/0.58 | {"building_multiplier": 3.0, "faction_trait": "lifesteal", "lifesteal": 0.1} | 高建筑伤害；面对军团时效率低。 |
| unit.mo.mortar | 旧墨抛墨臼 | mortar | 175 | 122 | 43/3.1 | 6.0/0.58 | {"radius": 1.2, "reflectable": false, "faction_trait": "lifesteal", "lifesteal": 0.1} | 远距范围弹；长前摇和低耐久可被突袭。 |
| unit.mo.chain | 旧墨连墨术士 | chain | 146 | 93 | 22/1.9 | 4.5/0.93 | {"chain_targets": 3, "chain_radius": 2.2, "reflectable": false, "faction_trait": "lifesteal", "lifesteal": 0.1} | 弹跳处理集群；分开站位降低价值。 |
| unit.mo.executioner | 旧墨断页刑兵 | executioner | 118 | 167 | 31/1.25 | 0.85/1.04 | {"execute_threshold": 0.35, "execute_multiplier": 1.7, "faction_trait": "lifesteal", "lifesteal": 0.1} | 收割低血单位；满血前排可以拖住。 |
| unit.mo.leech | 旧墨夺血纸客 | leech | 120 | 137 | 23/1.1 | 0.75/1.14 | {"lifesteal": 0.28, "faction_trait": "lifesteal"} | 近战吸血续航；控制和集中火力压过恢复。 |
| unit.mo.raider | 旧墨截金游兵 | raider | 84 | 113 | 17/0.8 | 0.7/1.3 | {"worker_multiplier": 2.4, "faction_trait": "lifesteal", "lifesteal": 0.1} | 快速截工；正面耐久不足。 |
| unit.mo.demolisher | 旧墨拆灯斧匠 | demolisher | 128 | 207 | 25/1.4 | 0.9/0.97 | {"building_multiplier": 2.8, "construction_multiplier": 1.5, "faction_trait": "lifesteal", "lifesteal": 0.1} | 抢拆设施尤其施工目标；怕远程与迟到。 |
| unit.mo.summoner | 旧墨唤卫符使 | summoner | 172 | 105 | 10/1.55 | 3.5/0.92 | {"auto_guardian_seconds": 12, "ability_interval": 7, "faction_trait": "lifesteal", "lifesteal": 0.1} | 周期召临时护卫；有限所有权与寿命避免无限成军。 |
| unit.mo.illusionist | 旧墨复影校书 | illusionist | 162 | 107 | 13/1.5 | 3.7/0.98 | {"auto_clone_seconds": 8, "ability_interval": 9, "faction_trait": "lifesteal", "lifesteal": 0.1} | 复制附近普通兵；有限寿命，禁复制链与巨人。 |
| unit.mo.saboteur | 旧墨熄台潜客 | saboteur | 130 | 119 | 19/1.15 | 0.8/1.25 | {"disable_facility_seconds": 3, "faction_trait": "lifesteal", "lifesteal": 0.1} | 短时熄灭设施能力；无法永久免费拆塔。 |
| unit.mo.warden | 旧墨钉页卫 | warden | 103 | 188 | 17/1.3 | 1.1/0.94 | {"root_seconds": 1.1, "faction_trait": "lifesteal", "lifesteal": 0.1} | 命中定身，敌人仍可攻击；长射程可反制。 |
| unit.mo.berserker | 旧墨破缄狂兵 | berserker | 125 | 205 | 27/1.15 | 0.8/1.07 | {"enrage_threshold": 0.35, "enrage_multiplier": 1.7, "faction_trait": "lifesteal", "lifesteal": 0.1} | 低血爆发；控制后清除而非慢慢消耗。 |
| unit.mo.caravan | 旧墨护矿执旗 | caravan | 115 | 162 | 14/1.05 | 2.8/1.07 | {"delivery_aura": 2, "aura_radius": 3.2, "faction_trait": "lifesteal", "lifesteal": 0.1} | 提高附近工人的每趟实际交付；依赖同路护运。 |
| unit.mo.oracle | 旧墨观墨师 | oracle | 146 | 98 | 20/1.7 | 4.8/0.94 | {"kill_mana": 5, "magic_damage": true, "faction_trait": "lifesteal", "lifesteal": 0.1} | 魔法输出与合法击杀回法；怕突袭，召唤不能刷回法。 |
| unit.mo.phoenix | 旧墨燃尽重卫 | phoenix | 165 | 244 | 28/1.7 | 0.9/0.85 | {"death_burst_damage": 45, "death_burst_radius": 1.7, "faction_trait": "lifesteal", "lifesteal": 0.1} | 死亡时局部爆发；不能伤到远处和另一条分离路线。 |
