# 当前交付：纸上兵戈 2.0.0

[2.0.0 下载、安装与验证说明](2.0.0/README.md)包含本次200图、十院400作战兵和完整线性故事更新后的Windows/Android程序与源码。

本目录直属的PaperWarfront-Windows-1.0.0.zip、PaperWarfront-Source-1.0.0.zip、windows/和android/保留上一版程序，属于三阵营原型历史交付。当前新版全部放在2.0.0/，请按版本选择。

[原作地图专项研究](../docs/research/swords-and-soldiers-map/README.md) · [当前实施证据](../docs/paper-warfront/17-规模扩展与实施进度.md)。
